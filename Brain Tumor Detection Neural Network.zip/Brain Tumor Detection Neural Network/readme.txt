The only file that truly works is "TumorDetectionNew" since that uses a pretrained CNN (convolutional neural network) from Kaggle.
